/*Take as input str, a string.
a).Write a recursive function which counts the number of times ‘hi’ appears in the string. 
Print the value returned. 
b).Write a recursive function which removes all ‘hi’ in the string. Print the value returned. 
c).Write a recursive function which replaces all ‘hi’ in the string with ‘bye’. Print the value returned. */

import java.util.Scanner;
public class CountRemoveReplacehi{
    public static int count(String s, int count ){

        if(s.length()==0){
            return count;
        }
        if(s.endsWith("hi")){
            count++;
        }
        return count(s.substring(0,s.length()-1),count);
    }
    public static void removehi(String s , String ans,int i,int len ){
        if(len<1){
            System.out.println(ans);
            return;
        }
        if(ans.startsWith("hi")){
            removehi(s, ans,i+2,len-2);}
        else{
            removehi(s.substring(i), ans+s.charAt(i), i+1, len-1);

        }}
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.next();
        System.out.println(count(s,0));
        removehi(s, "", 0,s.length());
        sc.close();
    }
}