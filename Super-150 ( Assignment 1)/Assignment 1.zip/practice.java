public class practice {
    public static void main(String[] args) {
        int num = 10;
        String s = num+"";
        System.out.println(s);
    }
}
